package net.nwie.awdtool;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class AWDTool {

	static String sourcePath = "c:\\AWD\\docvault\\recovery";
	static String destinationPath = "c:\\AWD\\docvault\\recovery";
	static String searchFileLocation = "c:\\AWD\\server\\success";

	public static void main(String[] args) {
		File sourceDir = new File(sourcePath);
		/*
		 * File[] nameFilterfiles = sourceDir.listFiles(nameFilter);
		 * moveFile(nameFilterfiles); File[] sizeFilterfiles =
		 * sourceDir.listFiles(sizeFilter); moveFile(sizeFilterfiles);
		 */
		File[] searchFilterfiles = sourceDir.listFiles(searchFilter);
		System.out.println("searchFilterfiles>>>>"+searchFilterfiles.length);
		searchFile(searchFilterfiles);
	}

	private static void searchFile(File[] files) {

		File destDir = new File(destinationPath);
		if (files.length == 0) {
			System.out.println("There is no such files");
			
		} else {
			for (File aFile : files) {
				try {
					 
						if (aFile.getName().contains("fn-awd")) {
						    System.out.println("aFile.getName()>>>>"+aFile.getName());
							File searchDir = new File(searchFileLocation);
							Path path = Paths.get(aFile.getName());
							Path fileName = path.getFileName();
							String fileStr = fileName.toString();
							//FileFilter wildCardFilter = new WildcardFileFilter(fileStr + "*");
							File[] searchFilterfiles = searchDir.listFiles();
							System.out.println("searchFilterfilesut " + searchFilterfiles.length);
							List<String> fileToWrite =null;
							try  {								
								List<String> lines = Files.readAllLines(aFile.toPath());
								

								// line.replaceAll("\\s+", "");
								while (lines != null && !lines.isEmpty()) {
								    System.out.println("List before : " + lines);
								    for (String line :lines){
								        
									
								    Pattern p = Pattern.compile(".*\\{ *(.*) *\\}.*");
							        Matcher m = p.matcher(line);
							        m.find();
							        String guidString = m.group(1);
							        System.out.println("guidString"+guidString);
							        System.out.println("length"+guidString.length());
																														
											for (File xmlFile : searchFilterfiles) {
												String guidMatchContents = convertDocumentToString(xmlFile);
												System.out.println("guidString->>>>>>>"+guidMatchContents.contains(guidString));
												if(guidMatchContents.contains(guidString)) {
												    lines.remove(line);
												    writeContents(line);
												 }
												       System.out.println("List after removel : " + lines);
												     
													
											}
										}
																		
								}
								
							}
							catch (Exception e) {
                                // TODO Auto-generated catch block
                                // Uncomment and replace with appropriate logger
                                // LOGGER.error(exception_var, exception_var);
                            }
							}
								
				}	
				catch (Exception e) {
                    // TODO Auto-generated catch block
                    // Uncomment and replace with appropriate logger
                    // LOGGER.error(exception_var, exception_var);
                }
			}
		}			
						}	
			
	
	
	private static String convertDocumentToString(File file) throws ParserConfigurationException, SAXException, IOException {
	    
	  
	    //an instance of factory that gives a document builder  
	   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
	   //an instance of builder to parse the specified xml file  
	   DocumentBuilder db = dbf.newDocumentBuilder();  
	   Document doc = db.parse(file);  

        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
           
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
            e.printStackTrace();
        }
        
        return null;
    }


	
	public static void readCDATAFromXMLUsingStax(File xmlFile, String brLine) {
		XMLStreamReader r = null;
		try (InputStream in = new BufferedInputStream(new FileInputStream(xmlFile));) {
			XMLInputFactory factory = XMLInputFactory.newInstance();
			r = factory.createXMLStreamReader(in);
			while (r.hasNext()) {
				switch (r.getEventType()) {
				case XMLStreamConstants.CHARACTERS:
				case XMLStreamConstants.CDATA:
					r.getText().contains(brLine);
					System.out.println(r.getText().contains(brLine));
					break;
				default:
					break;
				}
				r.next();
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			if (r != null) {
				try {
					r.close();
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
		}
	}
	
	private static void writeContents(String contents) 
	
	{
	
        File file = new File("c:\\demo\\abc.txt");

      
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter(file,true);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(e, e);
        }

       
        BufferedWriter writer = new BufferedWriter(fileWriter);

        
        try {
            writer.append(" ");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(e, e);
        }
       
        try {
            writer.append(contents);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(e, e);
        }
      

        // Step #6. free the resources.
        try {
            writer.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            // Uncomment and replace with appropriate logger
            // LOGGER.error(e, e);
        }

	}

	private static void moveFile(File[] files) {
		File destDir = new File(destinationPath);
		if (files.length == 0) {
			System.out.println("There is no such files");
		} else {
			for (File aFile : files) {
				try {
					if (!destDir.exists()) {
						destDir.mkdir();
					} else {
						aFile.renameTo(new File(destDir + "\\" + aFile.getName()));
						System.out.println(aFile.getName() + " - " + aFile.length());
					}
				} catch (Exception exp) {
					System.out.println(exp);
				}

			}
		}
	}

	static FilenameFilter nameFilter = new FilenameFilter() {
		public boolean accept(File file, String name) {
			if (name.contains("PaymentSummary")) {
				// filters files whose extension is PaymentSummary
				return true;
			} else {
				return false;
			}
		}
	};

	static FileFilter sizeFilter = new FileFilter() {
		public boolean accept(File file) {
			if (file.isFile() && file.length() <= 1 * 1024 ) {
				// filters files whose size less than or equal to 1MB
				return true;
			} else {
				return false;
			}
		}
	};

	static FileFilter searchFilter = new FileFilter() {
		public boolean accept(File file) {
			if (file.isFile() && file.length() > 1 * 1024) {
				// filters files whose size less than or equal to 1MB
				return true;
			} else {
				return false;
			}
		}
	};

	/*public static String removeExtension(String s) {

		String separator = System.getProperty("file.separator");
		String filename;

		// Remove the path upto the filename.
		int lastSeparatorIndex = s.lastIndexOf(separator);
		if (lastSeparatorIndex == -1) {
			filename = s;
		} else {
			filename = s.substring(lastSeparatorIndex + 1);
		}

		// Remove the extension.
		int extensionIndex = filename.lastIndexOf(".");
		if (extensionIndex == -1)
			return filename;

		return filename.substring(0, extensionIndex);
	}*/

}
